/* ==========================================================================
   PCT Property Intelligence — site behaviour
   Mobile nav, dropdown, reveal-on-scroll, accordion, form handling, cookies.
   No external dependencies. Progressive enhancement only.
   ========================================================================== */
(function () {
  "use strict";

  /* ---------- Mobile nav toggle ---------- */
  var navToggle = document.querySelector("[data-nav-toggle]");
  var mainNav = document.querySelector("[data-main-nav]");
  if (navToggle && mainNav) {
    navToggle.addEventListener("click", function () {
      var isOpen = mainNav.classList.toggle("is-open");
      navToggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
      document.body.style.overflow = isOpen ? "hidden" : "";
    });

    // Mobile dropdown accordions inside nav
    document.querySelectorAll(".nav-item-dropdown > .nav-link").forEach(function (link) {
      link.addEventListener("click", function (e) {
        if (window.innerWidth <= 980) {
          e.preventDefault();
          var parent = link.closest(".nav-item-dropdown");
          parent.classList.toggle("is-open");
        }
      });
    });

    // Close mobile nav when a real link is followed
    mainNav.querySelectorAll("a").forEach(function (a) {
      a.addEventListener("click", function () {
        if (window.innerWidth <= 980 && a.getAttribute("href") && !a.closest(".nav-item-dropdown > .nav-link")) {
          mainNav.classList.remove("is-open");
          navToggle.setAttribute("aria-expanded", "false");
          document.body.style.overflow = "";
        }
      });
    });
  }

  /* ---------- Reveal on scroll ---------- */
  var revealEls = document.querySelectorAll(".reveal");
  if ("IntersectionObserver" in window && revealEls.length) {
    var io = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            io.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: "0px 0px -40px 0px" }
    );
    revealEls.forEach(function (el) { io.observe(el); });
  } else {
    revealEls.forEach(function (el) { el.classList.add("is-visible"); });
  }

  /* ---------- Accordion (FAQ) ---------- */
  document.querySelectorAll(".accordion-trigger").forEach(function (trigger) {
    trigger.addEventListener("click", function () {
      var item = trigger.closest(".accordion-item");
      var panel = item.querySelector(".accordion-panel");
      var isOpen = item.classList.contains("is-open");

      item.parentElement.querySelectorAll(".accordion-item.is-open").forEach(function (open) {
        if (open !== item) {
          open.classList.remove("is-open");
          open.querySelector(".accordion-panel").style.maxHeight = null;
          open.querySelector(".accordion-trigger").setAttribute("aria-expanded", "false");
        }
      });

      if (isOpen) {
        item.classList.remove("is-open");
        panel.style.maxHeight = null;
        trigger.setAttribute("aria-expanded", "false");
      } else {
        item.classList.add("is-open");
        panel.style.maxHeight = panel.scrollHeight + "px";
        trigger.setAttribute("aria-expanded", "true");
      }
    });
  });

  /* ---------- Quote builder: combinable services (Phase 2) ---------- */
  var quoteBuilder = document.querySelector("[data-quote-builder]");
  var refreshQuoteSummary = function () {}; // reassigned below when the builder is present; kept function-scoped (not block-scoped) so it's safely callable from the submit handler further down, even in strict mode.
  if (quoteBuilder) {
    var serviceCheckboxes = quoteBuilder.querySelectorAll("[data-service-checkbox]");
    var chipList = quoteBuilder.querySelector("[data-quote-chips]");
    var submitBtn = document.querySelector("[data-quote-submit]");
    var submitDefaultLabel = submitBtn ? submitBtn.textContent.trim() : "";

    refreshQuoteSummary = function () {
      var selected = [];
      serviceCheckboxes.forEach(function (cb) {
        var card = cb.closest("[data-service-card]");
        if (cb.checked) {
          if (card) card.classList.add("is-selected");
          selected.push(cb.value);
        } else if (card) {
          card.classList.remove("is-selected");
        }
      });

      if (chipList) {
        if (selected.length) {
          chipList.innerHTML = selected.map(function (name) {
            return '<span class="chip">' + name + "</span>";
          }).join("");
        } else {
          chipList.innerHTML = '<span class="chip-empty">No services selected yet &mdash; choose at least one above.</span>';
        }
      }

      if (submitBtn) {
        var arrow = submitBtn.querySelector("svg");
        var arrowHtml = arrow ? arrow.outerHTML : "";
        var label = selected.length
          ? "Send Request — " + selected.length + (selected.length === 1 ? " service" : " services")
          : submitDefaultLabel.replace(/\s*$/, "");
        submitBtn.innerHTML = label + " " + arrowHtml;
      }
    };

    serviceCheckboxes.forEach(function (cb) {
      cb.addEventListener("change", refreshQuoteSummary);
    });

    quoteBuilder.querySelectorAll("[data-combo]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        var wanted = btn.getAttribute("data-combo").split("|");
        serviceCheckboxes.forEach(function (cb) {
          cb.checked = wanted.indexOf(cb.value) !== -1;
        });
        refreshQuoteSummary();
      });
    });

    refreshQuoteSummary();
  }

  /* ---------- Enquiry / quote form ---------- */
  var quoteForm = document.querySelector("[data-quote-form]");
  if (quoteForm) {
    /* Lightweight lead-tracking fields (Phase 2), captured client-side since
       there's no backend yet — see the "Lead tracking" note in README.md for
       how these are intended to feed a CRM once one is introduced. */
    var leadSourceField = quoteForm.querySelector("[data-lead-source]");
    if (leadSourceField) {
      var params = new URLSearchParams(window.location.search);
      var source = params.get("utm_source") || params.get("ref");
      if (!source && document.referrer) {
        try { source = "Referral: " + new URL(document.referrer).hostname; } catch (err) { source = null; }
      }
      leadSourceField.value = source || "Direct (pctpropertyintelligence.co.uk)";
    }

    quoteForm.addEventListener("submit", function (e) {
      e.preventDefault();
      var status = quoteForm.querySelector("[data-form-status]");
      var requiredFields = quoteForm.querySelectorAll("[required]");
      var valid = true;

      requiredFields.forEach(function (field) {
        if (!field.value || (field.type === "checkbox" && !field.checked)) {
          valid = false;
          field.style.borderColor = "#c0392b";
        } else {
          field.style.borderColor = "";
        }
      });

      var serviceInputs = quoteForm.querySelectorAll('[name="services"]');
      var anyServiceChecked = false;
      serviceInputs.forEach(function (cb) { if (cb.checked) anyServiceChecked = true; });
      if (serviceInputs.length && !anyServiceChecked) {
        valid = false;
        var builder = quoteForm.querySelector("[data-quote-builder]");
        if (builder) builder.style.outline = "1.5px solid #c0392b";
      } else {
        var builder2 = quoteForm.querySelector("[data-quote-builder]");
        if (builder2) builder2.style.outline = "";
      }

      if (!valid) {
        if (status) {
          status.textContent = serviceInputs.length && !anyServiceChecked
            ? "Please select at least one service, and fill in the required fields marked above."
            : "Please fill in the required fields marked above before submitting.";
          status.className = "form-status show error";
        }
        return;
      }

      var submittedAtField = quoteForm.querySelector("[data-submitted-at]");
      if (submittedAtField) submittedAtField.value = new Date().toISOString();

      /*
        Phase 1/2 note: this static site has no backend yet.
        Two zero-config options are wired below:
        1) If deployed on Netlify, this form already carries data-netlify="true"
           and a hidden form-name field, so Netlify Forms will capture it
           automatically with no extra code — including the lead-source and
           lead-status fields below, ready for a CRM (e.g. via Zapier/Make)
           to pick up later.
        2) As a universal fallback (any host), we also build a pre-filled
           mailto: link so the enquiry reaches the business inbox directly.
        A real backend/CRM integration is a later decision (see section 31 of
        the project brief) — not built yet, to avoid overbuilding ahead of it.
      */
      var data = new FormData(quoteForm);
      var grouped = {};
      var order = [];
      data.forEach(function (value, key) {
        if (key === "form-name" || key === "bot-field" || !value) return;
        if (!grouped[key]) { grouped[key] = []; order.push(key); }
        grouped[key].push(value);
      });
      var lines = order.map(function (key) {
        return key.replace(/[-_]/g, " ") + ": " + grouped[key].join(", ");
      });
      var subject = encodeURIComponent("New enquiry via website — " + (data.get("name") || ""));
      var body = encodeURIComponent(lines.join("\n"));
      var mailto = "mailto:info@pctpropertyintelligence.co.uk?subject=" + subject + "&body=" + body;

      if (status) {
        status.innerHTML =
          "Thank you — your request is ready to send. If your email client didn't just open, " +
          '<a href="' + mailto + '" style="color:inherit;text-decoration:underline;">click here to send it</a>.';
        status.className = "form-status show success";
      }
      quoteForm.reset();
      if (quoteBuilder) refreshQuoteSummary();
      window.location.href = mailto;
    });
  }

  /* ---------- Cookie consent banner ---------- */
  var COOKIE_KEY = "pct_cookie_consent";
  var banner = document.querySelector("[data-cookie-banner]");
  if (banner) {
    var stored = null;
    try { stored = window.localStorage.getItem(COOKIE_KEY); } catch (err) { stored = null; }

    if (!stored) {
      window.setTimeout(function () { banner.classList.add("show"); }, 600);
    }

    banner.querySelectorAll("[data-cookie-accept]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        try { window.localStorage.setItem(COOKIE_KEY, "accepted"); } catch (err) {}
        banner.classList.remove("show");
        /* Analytics is only initialised after acceptance — see analytics stub in <head>. */
        if (typeof window.pctEnableAnalytics === "function") window.pctEnableAnalytics();
      });
    });
    banner.querySelectorAll("[data-cookie-decline]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        try { window.localStorage.setItem(COOKIE_KEY, "declined"); } catch (err) {}
        banner.classList.remove("show");
      });
    });
  }

  /* ---------- Current year in footer ---------- */
  document.querySelectorAll("[data-year]").forEach(function (el) {
    el.textContent = new Date().getFullYear();
  });
})();
